<!--회원정보 변경 전 회원정보 보여주기-->

<?php include $_SERVER['DOCUMENT_ROOT']."/db_config.php"; ?>

<?php
    $user_pid = $_POST["user_pid"];
    $id;
    $name;
    $nickname;
    $email; 

    $statement = mysqli_prepare($con, "SELECT * FROM User_Info WHERE user_pid = '".$user_pid."'");
    mysqli_stmt_execute($statement);
    mysqli_stmt_bind_result($statement, $user_pid, $id, $code_pid, $password, $name, $nickname, $email, $icon);
    
    $response = array();
    $respnose["success"] = false;

    while(mysqli_stmt_fetch($statement)){
        $response["success"] = true;
        $response["id"] = $id;
        $response["code_pid"] = $code_pid;
        $response["name"] = $name;
        $response["nickname"] = $nickname;
        $response["email"] = $email;
    }

    echo json_encode($response);
?>

    