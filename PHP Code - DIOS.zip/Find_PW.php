<!--아이디, 이름, 이메일로 비밀번호 변경 위한 과정-->

<?php include $_SERVER['DOCUMENT_ROOT']."/db_config.php"; ?>

<?php
    
    $id = $_POST["id"];   
    $name = $_POST["name"];
    $email = $_POST["email"];

    $statement = mysqli_prepare($con, "SELECT * FROM User_Info WHERE id =? AND name = ? AND email = ?");    

    mysqli_stmt_bind_param($statement, "sss", $id, $name, $email);
    mysqli_stmt_execute($statement);

    mysqli_stmt_store_result($statement);
    mysqli_stmt_bind_result($statement, $user_pid, $id, $password, $name, $nickname, $email, $icon); //Find_PWChange.php에 넘기기 위한 변수 저장

    $response = array();
    $response["success"] = false;

    // 성공시 true 반환
    while(mysqli_stmt_fetch($statement)){
        $response["success"] = true;
        $response["id"] = $id;
    }
 
    echo json_encode($response);

?>