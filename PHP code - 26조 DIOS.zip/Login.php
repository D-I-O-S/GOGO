<?php include $_SERVER['DOCUMENT_ROOT']."/db_config.php"; ?>
<?php

    $id = $_POST["id"];
    $password = $_POST["password"];
    
    $statement = mysqli_prepare($con, "SELECT * FROM User_Info WHERE id = ? AND password = ?");
    mysqli_stmt_bind_param($statement, "ss", $id, $password);
    mysqli_stmt_execute($statement);
 
    mysqli_stmt_store_result($statement);
    mysqli_stmt_bind_result($statement, $user_pid, $id, $code_pid, $password, $name, $nickname, $email, $icon);
    
    $response = array();
    $response["success"] = false;
    
    
    while(mysqli_stmt_fetch($statement)) {
        $response["success"] = true;
        $response["user_pid"] = $user_pid;
        $response["id"] = $id;
        $response["code_pid"] = $code_pid;
        $response["password"] = $password;
        $response["name"] = $name;
        $response["nickname"] = $nickname;
        $response["email"] = $email;
        $response["icon"] = $icon;
    }

    echo json_encode($response);
?>
