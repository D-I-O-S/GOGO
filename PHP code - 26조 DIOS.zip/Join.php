<?php include $_SERVER['DOCUMENT_ROOT']."/db_config.php"; ?>
<?php 
 
    $user_pid = $_POST["user_pid"];
    $id = $_POST["id"];
    $password = $_POST["password"];
    $name = $_POST["name"];
    $nickname = $_POST["nickname"];
    $email = $_POST["email"];
    $icon = 1;
    $code_pid = $_POST["code_pid"];
    
    // auto_increment 초기화
    $mqq = mq("alter table User_Info auto_increment =1");

    $stmt = mysqli_prepare($con, "INSERT INTO User_Info VALUES (?,?,?,?,?,?,?,?)");
    mysqli_stmt_bind_param($stmt, "isissssi", $user_pid, $id, $code_pid, $password, $name, $nickname, $email, $icon);
    mysqli_stmt_execute($stmt); 

    $response = array();
    $response["success"] = true;


    echo json_encode($response);
?>
