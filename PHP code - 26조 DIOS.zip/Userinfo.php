<!--회원정보 변경. 아이디 보여주고 PW 입력, PW확인 입력, 이름 보여주고 닉네임 보여주고(바꿀수 있음-중복체크) 이메일 보여줌-->

<?php include $_SERVER['DOCUMENT_ROOT']."/db_config.php"; ?>

<?php
    $password = $_POST["password"];
    $nickname = $_POST["nickname"];
    $email = $_POST["email"];
    $user_pid = $_POST["user_pid"];
    $code_pid = $_POST["code_pid"];


    $statement = mysqli_prepare($con, "UPDATE User_Info SET password = ?, nickname = ?, email = ?, code_pid = ? WHERE user_pid = '".$user_pid."'");
    mysqli_stmt_bind_param($statement, "sssi", $password, $nickname, $email, $code_pid);
    mysqli_stmt_execute($statement);

    $response = array();
    $response["success"] = true;


    echo json_encode($response);

?>