<!--아이콘과 닉네임, 변경-- /우선 아이콘 제외 닉네임만 변경-->

<?php include $_SERVER['DOCUMENT_ROOT']."/db_config.php"; ?>

<?php
    $icon = $_POST["icon"];
    $nickname = $_POST["nickname"];
    $user_pid = $_POST["user_pid"];
    $code_pid = $_POST["code_pid"];
    $ref_name = $_POST["ref_name"];

    $sql1 = mq("UPDATE User_Info SET icon =?, nickname =? WHERE user_pid = '".$user_pid."'");
    $sql2 = mq("UPDATE Refrig SET ref_name = '".$ref_name."' WHERE code_pid = '".$code_pid."'");

    $response = array();
    $response["success"] = true;

    echo json_encode($response);

?>

