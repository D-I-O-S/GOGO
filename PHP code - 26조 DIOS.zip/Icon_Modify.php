<?php include $_SERVER['DOCUMENT_ROOT']."/db_config.php";

    $user_pid = $_POST['user_pid'];
    $icon = $_POST['icon'];
    
    $sql = mq("UPDATE User_Info SET icon = '".$icon."' WHERE user_pid = '".$user_pid."'");

    $response = array();
    $response["success"] = true;

    echo json_encode($response);
?>