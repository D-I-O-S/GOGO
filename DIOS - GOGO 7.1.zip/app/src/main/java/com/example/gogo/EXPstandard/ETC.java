package com.example.gogo.EXPstandard;

import androidx.fragment.app.Fragment;

public class ETC extends Fragment {
}
