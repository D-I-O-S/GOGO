<!--이름과 email로 ID 찾기-->
<?php include $_SERVER['DOCUMENT_ROOT']."/db_config.php"; ?>

<?php    
    $name = $_POST["name"]; //이름 적기
    $email = $_POST["email"]; //이메일 적기

    $stmt = mysqli_prepare($con, "SELECT * FROM User_Info WHERE name = ? AND email = ?"); //User_Info Table에 적은 이름과 이메일이 같은 줄은?    

    mysqli_stmt_bind_param($stmt, "ss", $name, $email);
    mysqli_stmt_execute($stmt); 

    mysqli_stmt_store_result($stmt);//결과를 클라이언트에 저장함 
    mysqli_stmt_bind_result($stmt, $user_pid, $id, $code_pid,$password, $name, $nickname, $email, $icon);//결과를 $userID에 바인딩함 
      

    $response = array();
    $response["success"] = false;

    while(mysqli_stmt_fetch($stmt)) {
        $response["success"] = true;
        $response["id"] = $id;
   }

    echo json_encode($response);

?>