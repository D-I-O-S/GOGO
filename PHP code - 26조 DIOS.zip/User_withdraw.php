<?php include $_SERVER['DOCUMENT_ROOT']."/db_config.php";

    $user_pid = $_POST["user_pid"];
    $str = "(알수 없음)";
    
    $sql = mq("SELECT * FROM Board WHERE user_pid ='".$user_pid."'");
    
    $sql2 = mq("SELECT * FROM Comments WHERE user_pid = user_pid ='".$user_pid."'");

    $num = mysqli_num_rows($sql) + mysqli_num_rows($sql2);

    $response = array();
    $response["success"] = false;
    
    if($num == 0){
        $stat = mq("DELETE FROM User_Info WHERE user_pid='".$user_pid."'");
        $response["success"] = true;
    }

    else {
        $stat2 = mq("UPDATE User_Info SET id = '".$str."',name = '".$str."', nickname = '".$str."' WHERE user_pid = '".$user_pid."'");
        $stat3 = mq("UPDATE Board SET nickname = '".$str."' WHERE user_pid = '".$user_pid."'");
        $stat4 = mq("UPDATE Comments SET nickname = '".$str."' WHERE user_pid = '".$user_pid."'");
        $response["success"] = true;
    }

    $sql3 = mq("DELETE FROM Enroll WHERE user_pid='".$user_pid."'");
    
    echo json_encode($response);

?>