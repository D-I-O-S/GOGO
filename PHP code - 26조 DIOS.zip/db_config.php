<?php

    $db = mysqli_connect("localhost","computdios","dios2020!","computdios");
    mysqli_query($db, "SET NAMES utf8");

    global $con;
    $con = new mysqli("localhost", "computdios", "dios2020!", "computdios");

	   function mq($sql)
	   {
		  global $db;

		  return $db->query($sql);
	   }
    
?>



