<?php include $_SERVER['DOCUMENT_ROOT']."/db_config.php"; ?>

<?php
    
    $id = $_POST["id"];
    $password = $_POST["password"];

    $statement = mysqli_prepare($con, "UPDATE User_Info SET password = ? WHERE id = ?");    
    mysqli_stmt_bind_param($statement, "ss", $password, $id);
    mysqli_stmt_execute($statement);

    $response = array();
    $response["success"] = true;

    echo json_encode($response);

?>