<?php include $_SERVER['DOCUMENT_ROOT']."/db_config.php"; ?>
<? 
    $code_pid = $_POST['code_pid'];

    $sql = mq("select ref_name from Refrig where code_pid = '".$code_pid."'");
    
    $response = array();
    $response["success"] = true;

    while($row = mysqli_fetch_array($sql)){
        $response["ref_name"] = $row[0];
    }

    echo json_encode($response);

?>